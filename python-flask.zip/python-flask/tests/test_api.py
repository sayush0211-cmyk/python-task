import pytest
import json
from datetime import date
from app import app, db, Task


@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test_todo.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()


@pytest.fixture
def sample_task(client):
    task = Task(
        title='Test Task',
        description='This is a test task',
        due_date=date(2024, 12, 31),
        status='pending'
    )
    db.session.add(task)
    db.session.commit()
    return task


class TestCreateTask:
    
    def test_create_task_success(self, client):
        response = client.post('/api/tasks',
                             data=json.dumps({
                                 'title': 'New Task',
                                 'description': 'Task description',
                                 'due_date': '2024-12-31',
                                 'status': 'pending'
                             }),
                             content_type='application/json')
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['title'] == 'New Task'
        assert data['description'] == 'Task description'
        assert data['status'] == 'pending'
        assert 'id' in data
    
    def test_create_task_minimal(self, client):
        response = client.post('/api/tasks',
                             data=json.dumps({'title': 'Minimal Task'}),
                             content_type='application/json')
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['title'] == 'Minimal Task'
        assert data['status'] == 'pending'
    
    def test_create_task_no_title(self, client):
        response = client.post('/api/tasks',
                             data=json.dumps({'description': 'No title'}),
                             content_type='application/json')
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_create_task_invalid_date(self, client):
        response = client.post('/api/tasks',
                             data=json.dumps({
                                 'title': 'Task',
                                 'due_date': 'invalid-date'
                             }),
                             content_type='application/json')
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data


class TestGetTasks:
    
    def test_get_all_tasks_empty(self, client):
        response = client.get('/api/tasks')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert isinstance(data, list)
        assert len(data) == 0
    
    def test_get_all_tasks(self, client, sample_task):
        task2 = Task(title='Second Task', status='completed')
        db.session.add(task2)
        db.session.commit()
        
        response = client.get('/api/tasks')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert len(data) == 2
        assert any(task['title'] == 'Test Task' for task in data)
        assert any(task['title'] == 'Second Task' for task in data)
    
    def test_get_task_by_id(self, client, sample_task):
        response = client.get(f'/api/tasks/{sample_task.id}')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['id'] == sample_task.id
        assert data['title'] == 'Test Task'
        assert data['description'] == 'This is a test task'
    
    def test_get_task_not_found(self, client):
        response = client.get('/api/tasks/999')
        
        assert response.status_code == 404
        data = json.loads(response.data)
        assert 'error' in data


class TestUpdateTask:
    
    def test_update_task_full(self, client, sample_task):
        response = client.put(f'/api/tasks/{sample_task.id}',
                            data=json.dumps({
                                'title': 'Updated Task',
                                'description': 'Updated description',
                                'due_date': '2025-01-15',
                                'status': 'in_progress'
                            }),
                            content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['title'] == 'Updated Task'
        assert data['description'] == 'Updated description'
        assert data['status'] == 'in_progress'
    
    def test_update_task_partial(self, client, sample_task):
        response = client.put(f'/api/tasks/{sample_task.id}',
                            data=json.dumps({
                                'title': 'New Title',
                                'status': 'completed'
                            }),
                            content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['title'] == 'New Title'
        assert data['status'] == 'completed'
        assert data['description'] == 'This is a test task'
    
    def test_update_task_status_only(self, client, sample_task):
        response = client.put(f'/api/tasks/{sample_task.id}',
                            data=json.dumps({'status': 'completed'}),
                            content_type='application/json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'completed'
    
    def test_update_task_invalid_status(self, client, sample_task):
        response = client.put(f'/api/tasks/{sample_task.id}',
                            data=json.dumps({'status': 'invalid_status'}),
                            content_type='application/json')
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_update_task_invalid_date(self, client, sample_task):
        response = client.put(f'/api/tasks/{sample_task.id}',
                            data=json.dumps({'due_date': 'invalid-date'}),
                            content_type='application/json')
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data
    
    def test_update_task_not_found(self, client):
        response = client.put('/api/tasks/999',
                            data=json.dumps({'title': 'New Title'}),
                            content_type='application/json')
        
        assert response.status_code == 404


class TestDeleteTask:
    
    def test_delete_task_success(self, client, sample_task):
        task_id = sample_task.id
        response = client.delete(f'/api/tasks/{task_id}')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'message' in data
        
        get_response = client.get(f'/api/tasks/{task_id}')
        assert get_response.status_code == 404
    
    def test_delete_task_not_found(self, client):
        response = client.delete('/api/tasks/999')
        
        assert response.status_code == 404


class TestTaskModel:
    
    def test_task_to_dict(self, client):
        task = Task(
            title='Test Task',
            description='Description',
            due_date=date(2024, 12, 31),
            status='pending'
        )
        db.session.add(task)
        db.session.commit()
        
        task_dict = task.to_dict()
        assert task_dict['title'] == 'Test Task'
        assert task_dict['description'] == 'Description'
        assert task_dict['status'] == 'pending'
        assert 'id' in task_dict
        assert 'created_at' in task_dict


class TestErrorHandling:
    
    def test_404_handler(self, client):
        response = client.get('/api/nonexistent')
        assert response.status_code == 404
    
    def test_invalid_json(self, client):
        response = client.post('/api/tasks',
                             data='invalid json',
                             content_type='application/json')
        assert response.status_code in [400, 500]
    
    def test_empty_request_body(self, client):
        task = Task(title='Test', status='pending')
        db.session.add(task)
        db.session.commit()
        
        response = client.put(f'/api/tasks/{task.id}',
                            data=json.dumps({}),
                            content_type='application/json')
        assert response.status_code in [200, 400]
