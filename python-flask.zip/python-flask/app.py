import logging
import os
from datetime import datetime
from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.exceptions import BadRequest

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('todo_app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

database_type = os.environ.get('DATABASE_TYPE', 'mysql')

if database_type == 'mysql':
    db_user = os.environ.get('DB_USER', 'root')
    db_password = os.environ.get('DB_PASSWORD', '')
    db_host = os.environ.get('DB_HOST', 'localhost')
    db_name = os.environ.get('DB_NAME', 'todo_db')
    app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}'
else:
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todo.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


class Task(db.Model):
    __tablename__ = 'tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    due_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(20), default='pending', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


@app.errorhandler(404)
def not_found(error):
    logger.warning(f"404 error: {request.url}")
    return jsonify({'error': 'Resource not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    logger.error(f"500 error: {str(error)}")
    return jsonify({'error': 'Internal server error'}), 500


@app.errorhandler(BadRequest)
def bad_request(error):
    logger.warning(f"400 error: {str(error)}")
    return jsonify({'error': 'Bad request', 'message': str(error)}), 400


@app.route('/')
def index():
    try:
        logger.info("Rendering index page")
        return render_template('index.html')
    except Exception as e:
        logger.error(f"Error rendering index page: {str(e)}")
        raise


@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    try:
        logger.info("Fetching all tasks")
        tasks = Task.query.all()
        return jsonify([task.to_dict() for task in tasks]), 200
    except Exception as e:
        logger.error(f"Error fetching tasks: {str(e)}")
        return jsonify({'error': 'Failed to fetch tasks', 'message': str(e)}), 500


@app.route('/api/tasks/<int:task_id>', methods=['GET'])
def get_task(task_id):
    try:
        logger.info(f"Fetching task with ID: {task_id}")
        task = Task.query.get_or_404(task_id)
        return jsonify(task.to_dict()), 200
    except Exception as e:
        logger.error(f"Error fetching task {task_id}: {str(e)}")
        return jsonify({'error': 'Failed to fetch task', 'message': str(e)}), 500


@app.route('/api/tasks', methods=['POST'])
def create_task():
    try:
        data = request.get_json()
        
        if not data or 'title' not in data:
            logger.warning("Attempt to create task without title")
            return jsonify({'error': 'Title is required'}), 400
        
        due_date = None
        if 'due_date' in data and data['due_date']:
            try:
                due_date = datetime.strptime(data['due_date'], '%Y-%m-%d').date()
            except ValueError:
                logger.warning(f"Invalid date format: {data['due_date']}")
                return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
        
        task = Task(
            title=data['title'],
            description=data.get('description', ''),
            due_date=due_date,
            status=data.get('status', 'pending')
        )
        
        db.session.add(task)
        db.session.commit()
        
        logger.info(f"Created task with ID: {task.id}")
        return jsonify(task.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating task: {str(e)}")
        return jsonify({'error': 'Failed to create task', 'message': str(e)}), 500


@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    try:
        task = Task.query.get_or_404(task_id)
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        if 'title' in data:
            task.title = data['title']
        if 'description' in data:
            task.description = data['description']
        if 'due_date' in data:
            if data['due_date']:
                try:
                    task.due_date = datetime.strptime(data['due_date'], '%Y-%m-%d').date()
                except ValueError:
                    logger.warning(f"Invalid date format: {data['due_date']}")
                    return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
            else:
                task.due_date = None
        if 'status' in data:
            if data['status'] not in ['pending', 'in_progress', 'completed']:
                return jsonify({'error': 'Status must be: pending, in_progress, or completed'}), 400
            task.status = data['status']
        
        db.session.commit()
        
        logger.info(f"Updated task with ID: {task_id}")
        return jsonify(task.to_dict()), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating task {task_id}: {str(e)}")
        return jsonify({'error': 'Failed to update task', 'message': str(e)}), 500


@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    try:
        task = Task.query.get_or_404(task_id)
        db.session.delete(task)
        db.session.commit()
        
        logger.info(f"Deleted task with ID: {task_id}")
        return jsonify({'message': 'Task deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting task {task_id}: {str(e)}")
        return jsonify({'error': 'Failed to delete task', 'message': str(e)}), 500


def init_db():
    with app.app_context():
        db.create_all()
        logger.info("Database initialized")


if __name__ == '__main__':
    init_db()
    logger.info("Starting Flask To-Do List Application")
    app.run(debug=True, host='0.0.0.0', port=5000)
