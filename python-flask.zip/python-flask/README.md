# To-Do List Web Application

A full-featured To-Do List web application built with Flask, featuring RESTful APIs, MySQL database integration, and a modern web interface.

## Project Overview

This application provides a complete task management system with:
- RESTful API endpoints for CRUD operations
- MySQL database support
- Modern, responsive web interface
- Comprehensive error handling and logging
- Complete test coverage

## Features

- **RESTful API** - Complete CRUD operations for task management
- **MySQL Database** - Robust database support for task storage
- **Web Interface** - Modern, responsive UI with real-time updates
- **Task Management** - Title, description, due date, and status tracking
- **Testing** - Comprehensive test suite with pytest
- **Logging** - Detailed logging for debugging and monitoring
- **Error Handling** - Robust error handling throughout the application

## Technology Stack

- **Backend Framework**: Flask 3.0.0
- **Database**: MySQL
- **ORM**: SQLAlchemy
- **Testing**: pytest
- **Frontend**: HTML, CSS, JavaScript

## Project Structure

```
python-flask/
├── app.py                 # Main Flask application
├── config.py              # Database configuration
├── database.sql           # MySQL database schema
├── requirements.txt       # Python dependencies
├── README.md             # Project documentation
├── templates/
│   └── index.html        # Web interface template
└── tests/
    ├── __init__.py
    └── test_api.py       # API endpoint tests
```

## Installation and Setup

### Prerequisites

- Python 3.7 or higher
- pip (Python package manager)
- MySQL Server

### Step 1: Install MySQL

Install MySQL server on your system:
- Windows: Download from [MySQL Official Website](https://dev.mysql.com/downloads/mysql/)
- Linux: `sudo apt-get install mysql-server`
- macOS: `brew install mysql`

### Step 2: Create Database

Run the SQL script to create the database:

```bash
mysql -u root -p < database.sql
```

Or manually:

```sql
CREATE DATABASE IF NOT EXISTS todo_db;
USE todo_db;

CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    due_date DATE,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_due_date (due_date)
);
```

### Step 3: Install Python Dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Configure Database Connection

Set environment variables:

**Windows (Command Prompt):**
```cmd
set DATABASE_TYPE=mysql
set DB_USER=root
set DB_PASSWORD=your_password
set DB_HOST=localhost
set DB_NAME=todo_db
```

**Windows (PowerShell):**
```powershell
$env:DATABASE_TYPE="mysql"
$env:DB_USER="root"
$env:DB_PASSWORD="your_password"
$env:DB_HOST="localhost"
$env:DB_NAME="todo_db"
```

**Linux/macOS:**
```bash
export DATABASE_TYPE=mysql
export DB_USER=root
export DB_PASSWORD=your_password
export DB_HOST=localhost
export DB_NAME=todo_db
```

### Step 5: Run the Application

```bash
python app.py
```

The application will start on `http://localhost:5000`

## API Documentation

### Base URL
```
http://localhost:5000/api
```

### Endpoints

#### 1. Get All Tasks

**Endpoint:** `GET /api/tasks`

**Response:**
```json
[
  {
    "id": 1,
    "title": "Complete project",
    "description": "Finish the Flask To-Do application",
    "due_date": "2024-12-31",
    "status": "pending",
    "created_at": "2024-12-30T10:00:00"
  }
]
```

**Status Codes:**
- `200 OK` - Success

---

#### 2. Get Task by ID

**Endpoint:** `GET /api/tasks/<id>`

**Response:**
```json
{
  "id": 1,
  "title": "Complete project",
  "description": "Finish the Flask To-Do application",
  "due_date": "2024-12-31",
  "status": "pending",
  "created_at": "2024-12-30T10:00:00"
}
```

**Status Codes:**
- `200 OK` - Success
- `404 Not Found` - Task not found

---

#### 3. Create Task

**Endpoint:** `POST /api/tasks`

**Request Body:**
```json
{
  "title": "New Task",
  "description": "Task description (optional)",
  "due_date": "2024-12-31",
  "status": "pending"
}
```

**Required Fields:**
- `title` (string) - Task title

**Optional Fields:**
- `description` (string) - Task description
- `due_date` (string) - Due date in `YYYY-MM-DD` format
- `status` (string) - Task status: `pending`, `in_progress`, or `completed` (default: `pending`)

**Response:**
```json
{
  "id": 3,
  "title": "New Task",
  "description": "Task description",
  "due_date": "2024-12-31",
  "status": "pending",
  "created_at": "2024-12-30T11:00:00"
}
```

**Status Codes:**
- `201 Created` - Task created successfully
- `400 Bad Request` - Invalid input

**Example using cURL:**
```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "title": "New Task",
    "description": "Task description",
    "due_date": "2024-12-31",
    "status": "pending"
  }'
```

---

#### 4. Update Task

**Endpoint:** `PUT /api/tasks/<id>`

**Request Body:**
```json
{
  "title": "Updated Task",
  "description": "Updated description",
  "due_date": "2025-01-15",
  "status": "completed"
}
```

**Note:** All fields are optional. Only include fields you want to update.

**Response:**
```json
{
  "id": 1,
  "title": "Updated Task",
  "description": "Updated description",
  "due_date": "2025-01-15",
  "status": "completed",
  "created_at": "2024-12-30T10:00:00"
}
```

**Status Codes:**
- `200 OK` - Task updated successfully
- `400 Bad Request` - Invalid input
- `404 Not Found` - Task not found

**Example using cURL:**
```bash
curl -X PUT http://localhost:5000/api/tasks/1 \
  -H "Content-Type: application/json" \
  -d '{
    "status": "completed"
  }'
```

---

#### 5. Delete Task

**Endpoint:** `DELETE /api/tasks/<id>`

**Response:**
```json
{
  "message": "Task deleted successfully"
}
```

**Status Codes:**
- `200 OK` - Task deleted successfully
- `404 Not Found` - Task not found

**Example using cURL:**
```bash
curl -X DELETE http://localhost:5000/api/tasks/1
```

---

## Task Status Values

The `status` field accepts the following values:
- `pending` - Task is not yet started
- `in_progress` - Task is currently being worked on
- `completed` - Task is finished

## Database Schema

### Tasks Table

| Column | Type | Constraints |
|--------|------|-------------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT |
| title | VARCHAR(200) | NOT NULL |
| description | TEXT | NULL |
| due_date | DATE | NULL |
| status | VARCHAR(20) | NOT NULL, DEFAULT 'pending' |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP |

## Web Interface

The application includes a modern web interface accessible at `http://localhost:5000`. Features:

- **Add New Tasks** - Form to create tasks with all fields
- **View All Tasks** - Display all tasks in a card-based layout
- **Update Tasks** - Edit existing tasks or change their status
- **Delete Tasks** - Remove tasks with confirmation
- **Real-time Updates** - Interface automatically updates after operations

The web interface uses JavaScript `fetch` API to interact with the RESTful endpoints, demonstrating the integration between templates and APIs.

## Template-API Integration

The templates are integrated with API endpoints using JavaScript:

1. **Form Submission** - Uses `fetch` API with POST method to create tasks
2. **Task Display** - Uses `fetch` API with GET method to retrieve all tasks
3. **Task Updates** - Uses `fetch` API with PUT method to update tasks
4. **Task Deletion** - Uses `fetch` API with DELETE method to remove tasks

All API calls are made asynchronously, and the UI updates automatically after each operation.

## Testing

Run the test suite:

```bash
pytest tests/ -v
```

Run tests with coverage:

```bash
pytest tests/ --cov=app
```

### Test Coverage

The test suite includes:
- Creating tasks (with and without optional fields)
- Retrieving all tasks
- Retrieving a specific task
- Updating tasks (full and partial updates)
- Deleting tasks
- Error handling (404, 400, invalid inputs)
- Task model serialization

## Logging

The application logs all operations to:
- **Console** - Real-time log output
- **File** - `todo_app.log` file

Log levels:
- `INFO` - General application flow
- `WARNING` - Non-critical issues
- `ERROR` - Critical errors

## Error Handling

The application implements comprehensive error handling:

- **400 Bad Request** - Invalid input data
- **404 Not Found** - Resource not found
- **500 Internal Server Error** - Server-side errors

All errors return JSON responses with descriptive error messages. Database transactions are rolled back on errors to maintain data integrity.

## Implementation Details

### Code Structure

- **app.py** - Main application file containing:
  - Database models (Task)
  - API endpoints (CRUD operations)
  - Template routes
  - Error handlers
  - Logging configuration

- **templates/index.html** - Single-page application with:
  - Task creation form
  - Task list display
  - JavaScript for API integration using fetch

- **tests/test_api.py** - Comprehensive test suite for all endpoints

### Best Practices Implemented

- RESTful API design
- Proper HTTP status codes
- Input validation
- Error handling and logging
- Database transactions with rollback on errors
- Code organization and readability
- Comprehensive documentation

## Deployment

### Production Considerations

1. Use a production WSGI server (e.g., Gunicorn)
2. Use environment variables for sensitive configuration
3. Disable debug mode
4. Set up proper logging with rotation
5. Add authentication/authorization if needed
6. Use HTTPS for secure communication

## Troubleshooting

### MySQL Connection Issues

1. Verify MySQL server is running:
   ```bash
   mysql -u root -p
   ```

2. Check database exists:
   ```sql
   SHOW DATABASES;
   USE todo_db;
   SHOW TABLES;
   ```

3. Verify credentials in environment variables

4. Check MySQL user permissions:
   ```sql
   GRANT ALL PRIVILEGES ON todo_db.* TO 'root'@'localhost';
   FLUSH PRIVILEGES;
   ```

### Python Not Found

If `python` command is not recognized:
- Install Python from [python.org](https://www.python.org/downloads/)
- During installation, check "Add Python to PATH"
- Use `py` launcher on Windows as alternative

### Port Already in Use

Change the port in `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=8080)
```

## License

This project is created for educational purposes.

## Author

Developed as part of a Flask To-Do List application assignment.

---

## Quick Start

```bash
# 1. Create MySQL database
mysql -u root -p < database.sql

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set environment variables
export DATABASE_TYPE=mysql
export DB_USER=root
export DB_PASSWORD=password
export DB_NAME=todo_db

# 4. Run application
python app.py

# 5. Run tests
pytest tests/ -v
```

Access the application at: `http://localhost:5000`
