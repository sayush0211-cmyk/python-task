import os

DATABASE_TYPE = os.environ.get('DATABASE_TYPE', 'mysql')

DB_CONFIG = {
    'user': os.environ.get('DB_USER', 'root'),
    'password': os.environ.get('DB_PASSWORD', ''),
    'host': os.environ.get('DB_HOST', 'localhost'),
    'database': os.environ.get('DB_NAME', 'todo_db')
}

